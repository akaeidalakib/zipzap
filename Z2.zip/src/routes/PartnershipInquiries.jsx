
import React from "react";
import { Center, Heading } from "@chakra-ui/react";
export default function PartnershipInquiries() {
  return (
    <Center pt="8" height="100vh">
      <Heading>PartnershipInquiries</Heading>
    </Center>
  );
}

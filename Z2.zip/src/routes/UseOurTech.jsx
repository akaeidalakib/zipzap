import { Center, Heading } from "@chakra-ui/react";
export default function UseOurTech() {
  return (
    <Center pt="8" height="100vh">
      <Heading>UseOurTech</Heading>
    </Center>
  );
}

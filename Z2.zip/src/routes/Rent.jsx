import React from "react";
import { Center, Heading } from "@chakra-ui/react";
export default function Rent() {
  return (
    <Center pt="8" height="100vh">
      <Heading>Rent</Heading>
    </Center>
  );
}
